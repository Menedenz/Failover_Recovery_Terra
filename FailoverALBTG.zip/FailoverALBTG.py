import boto3
import os

def lambda_handler(event, context):
    ec2 = boto3.client('ec2')
    elbv2 = boto3.client('elbv2')
    events = boto3.client('events')
    
    # Retrieve environment variables
    operation = os.getenv('OPERATION')
    alb_arn = os.getenv('ALB_ARN')
    target_group_active_arn = os.getenv('TARGET_GROUP_ACTIVE_ARN')
    target_group_passive_arn = os.getenv('TARGET_GROUP_PASSIVE_ARN')
    instance_id = os.getenv('INSTANCE_ID')
    listener_arn = os.getenv('LISTENER_ARN')
    event_rule_name = os.getenv('EVENT_RULE_NAME')
    try:
        if operation == 'failover':
            failover_successful = handle_failover(elbv2, listener_arn, target_group_active_arn, target_group_passive_arn)
            if failover_successful:  # Only update to 'recovery' if failover is successful
                create_eventbridge_rule(events, event_rule_name, context.invoked_function_arn)
                update_lambda_environment_variable('recovery')
        elif operation == 'recovery':
            recovery_successful = handle_recovery(ec2, elbv2, listener_arn, target_group_active_arn, target_group_passive_arn, instance_id, events, event_rule_name)
            if recovery_successful:  # Only update to 'failover' if recovery is successful
                update_lambda_environment_variable('failover')
        else:
            raise ValueError("Invalid operation specified")
        
    except Exception as e:      
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': f"Operation failed: {str(e)}"
        }
    return {
        'statusCode': 200,
        'body': 'Operation completed successfully'
    }

def handle_failover(elbv2, listener_arn, target_group_active_arn, target_group_passive_arn):
    try:
        elbv2.modify_listener(
            ListenerArn=listener_arn,
            DefaultActions=[
                {
                    'Type': 'forward',
                    'ForwardConfig': {
                        'TargetGroups': [
                            {'TargetGroupArn': target_group_passive_arn, 'Weight': 100},
                            {'TargetGroupArn': target_group_active_arn, 'Weight': 0}
                        ],
                        'TargetGroupStickinessConfig': {'Enabled': False}
                    }
                },
            ]
        )
        return True  # Failover was successful
    except Exception as e:
        print(e)
        return False  # Failover was not successful

def handle_recovery(ec2, elbv2, listener_arn, target_group_active_arn, target_group_passive_arn, instance_id, events, event_rule_name):
    try:
        response = ec2.describe_instance_status(InstanceIds=[instance_id])
        if response['InstanceStatuses']:
            instance_status = response['InstanceStatuses'][0]['InstanceState']['Name']
            if instance_status == 'running':
                elbv2.modify_listener(
                    ListenerArn=listener_arn,
                    DefaultActions=[
                        {
                            'Type': 'forward',
                            'ForwardConfig': {
                                'TargetGroups': [
                                    {'TargetGroupArn': target_group_active_arn, 'Weight': 100},
                                    {'TargetGroupArn': target_group_passive_arn, 'Weight': 0}
                                ],
                                'TargetGroupStickinessConfig': {'Enabled': False}
                            }
                        },
                    ]
                )
                delete_eventbridge_rule(events, event_rule_name)
                return True  # Recovery was successful
            else:
                print(f"Instance {instance_id} is not running. Current state: {instance_status}")
                return False  # Recovery was not successful
        else:
            print(f"No status information found for instance {instance_id}")
            return False  # Recovery was not successful
    except Exception as e:
        print(e)
        return False  # Ensure the function returns False on error

def create_eventbridge_rule(events, event_rule_name, lambda_arn):
    try:
        events.put_rule(
            Name=event_rule_name,
            ScheduleExpression='rate(1 minute)',
            State='ENABLED',
        )
        events.put_targets(
            Rule=event_rule_name,
            Targets=[
                {'Id': '1', 'Arn': lambda_arn}
            ]
        )
    except Exception as e:
        print(e)
        raise

def delete_eventbridge_rule(events, event_rule_name):
    try:
        events.remove_targets(Rule=event_rule_name, Ids=['1'])
        events.delete_rule(Name=event_rule_name)
    except Exception as e:
        print(e)
        raise

def update_lambda_environment_variable(operation):
    lambda_client = boto3.client('lambda')
    function_name = os.getenv('AWS_LAMBDA_FUNCTION_NAME')
    response = lambda_client.update_function_configuration(
        FunctionName=function_name,
        Environment={
            'Variables': {
                'OPERATION': operation,
                'ALB_ARN': os.getenv('ALB_ARN'),
                'TARGET_GROUP_ACTIVE_ARN': os.getenv('TARGET_GROUP_ACTIVE_ARN'),
                'TARGET_GROUP_PASSIVE_ARN': os.getenv('TARGET_GROUP_PASSIVE_ARN'),
                'INSTANCE_ID': os.getenv('INSTANCE_ID'),
                'LISTENER_ARN': os.getenv('LISTENER_ARN'),
                'EVENT_RULE_NAME': os.getenv('EVENT_RULE_NAME')
            }
        }
    )
    print(f"Updated OPERATION to {operation}")

